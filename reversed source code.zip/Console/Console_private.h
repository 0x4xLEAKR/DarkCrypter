/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef CONSOLE_PRIVATE_H
#define CONSOLE_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"0.1.0.108"
#define VER_MAJOR	0
#define VER_MINOR	1
#define VER_RELEASE	0
#define VER_BUILD	108
#define COMPANY_NAME	"J3kill Soft."
#define FILE_VERSION	"0.1.0.108"
#define FILE_DESCRIPTION	"PE Runtime Crypter (Console)"
#define INTERNAL_NAME	"Console"
#define LEGAL_COPYRIGHT	"Copyright � 2017 J3kill Soft."
#define LEGAL_TRADEMARKS	"Crypt0r"
#define ORIGINAL_FILENAME	"Console.exe"
#define PRODUCT_NAME	"Crypt0r"
#define PRODUCT_VERSION	"0.1.0.108"

#endif /*CONSOLE_PRIVATE_H*/
